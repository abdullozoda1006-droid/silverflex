/*
 * Назначение: проверка и отправка формы SilverFlex через локальный серверный обработчик.
 * Зависимости: form.html, модуль капчи-заглушки и браузерный Fetch API.
 * От этого файла зависит: тестовый и рабочий сценарии отправки заявки.
 */

(() => {
  'use strict';

  /* ===== РАЗДЕЛ: Настройки ===== */
  const TEST_MODE = true;
  const FORM_ENDPOINT = '/api/contact';
  const SUCCESS_MESSAGE = 'Спасибо! Мы свяжемся с вами в ближайшее время.';
  const ERROR_MESSAGE = 'Не удалось отправить заявку. Позвоните +375 (25) 710-48-02 или напишите на silverflex.f@mail.ru.';
  const form = document.querySelector('#sf-request-form');

  if (!form) return;

  const submitButton = form.querySelector('[data-submit]');
  const status = form.querySelector('[data-form-status]');

  /* ===== РАЗДЕЛ: Вспомогательные функции ===== */

  /**
   * Удаляет лишние пробелы из пользовательского текста.
   * @param {FormDataEntryValue | null} value Исходное значение поля.
   * @returns {string} Очищенный текст.
   */
  function clean(value) {
    return typeof value === 'string' ? value.trim() : '';
  }

  /**
   * Показывает или очищает ошибку поля.
   * @param {string} fieldId Идентификатор поля без префикса ошибки.
   * @param {string} message Текст ошибки или пустая строка.
   * @returns {void}
   */
  function setFieldError(fieldId, message) {
    const field = document.querySelector(`#${fieldId}`);
    const error = document.querySelector(`#${fieldId}-error`);
    if (field) field.setAttribute('aria-invalid', String(Boolean(message)));
    if (error) error.textContent = message;
  }

  /**
   * Проверяет телефон без привязки к одному оператору или стране.
   * @param {string} phone Введённый телефон.
   * @returns {boolean} Достаточно ли цифр и допустимы ли символы.
   */
  function isPhoneValid(phone) {
    const digits = phone.replace(/\D/g, '');
    return /^[+\d\s().-]+$/.test(phone) && digits.length >= 9 && digits.length <= 15;
  }

  /**
   * Проверяет локальную капчу-заглушку.
   * @returns {boolean} Пройдена ли проверка.
   */
  function isCaptchaComplete() {
    return Boolean(form.querySelector('#sf-captcha')?.checked);
  }

  /**
   * Проверяет обязательные поля и ограничения формы.
   * @returns {boolean} Можно ли переходить к отправке.
   */
  function validateForm() {
    const data = new FormData(form);
    const name = clean(data.get('name'));
    const phone = clean(data.get('phone'));
    const emailField = form.querySelector('#sf-email');
    const email = clean(data.get('email'));
    const message = clean(data.get('project_message'));
    const phoneDigits = phone.replace(/\D/g, '');
    const phoneProvided = phoneDigits.length > 1;
    const emailProvided = Boolean(email);
    const hasContact = phoneProvided || emailProvided;
    const phoneValid = !phoneProvided || isPhoneValid(phone);
    const emailValid = !emailProvided || emailField.validity.valid;
    let isValid = true;

    setFieldError('sf-name', name ? '' : 'Укажите имя.');
    setFieldError('sf-phone', phoneValid ? (hasContact ? '' : 'Укажите телефон или e-mail.') : 'Проверьте формат телефона.');
    setFieldError('sf-email', emailValid ? '' : 'Проверьте формат e-mail.');
    setFieldError('sf-message', message ? '' : 'Опишите задачу или продукт.');
    setFieldError('sf-consent', form.querySelector('#sf-consent').checked ? '' : 'Подтвердите согласие на обработку данных.');

    if (!name || !hasContact || !phoneValid || !emailValid || !message || !form.querySelector('#sf-consent').checked) {
      isValid = false;
    }

    const captchaError = form.querySelector('#sf-captcha-error');
    if (captchaError) captchaError.textContent = isCaptchaComplete() ? '' : 'Подтвердите, что вы не робот.';
    return isValid && isCaptchaComplete();
  }

  /**
   * Формирует данные для защищённого серверного обработчика.
   * @param {FormData} sourceData Исходные данные формы.
   * @returns {Record<string, string | boolean>} Очищенные данные заявки.
   */
  function buildRequestData(sourceData) {
    const phone = clean(sourceData.get('phone'));
    const phoneHasNumber = phone.replace(/\D/g, '').length > 1;
    return {
      name: clean(sourceData.get('name')),
      company: clean(sourceData.get('company')),
      phone: phoneHasNumber ? phone : '',
      email: clean(sourceData.get('email')),
      packagingType: clean(sourceData.get('packaging_type')),
      quantity: clean(sourceData.get('quantity')),
      message: clean(sourceData.get('project_message')),
      consent: sourceData.get('consent') === 'on',
      captchaToken: clean(sourceData.get('captcha_token')),
      website: clean(sourceData.get('website')),
      page: window.location.href
    };
  }

  /**
   * Переключает кнопку и сообщение формы во время запроса.
   * @param {boolean} isSending Идёт ли отправка.
   * @returns {void}
   */
  function setSendingState(isSending) {
    submitButton.disabled = isSending;
    submitButton.textContent = isSending ? 'Отправляем…' : 'Запросить расчёт';
  }

  /**
   * Показывает итоговое сообщение и переносит на него фокус.
   * @param {'success' | 'error'} state Тип результата.
   * @param {string} message Сообщение посетителю.
   * @returns {void}
   */
  function showStatus(state, message) {
    status.dataset.state = state;
    status.textContent = message;
    status.focus();
  }

  /* ===== РАЗДЕЛ: Отправка ===== */

  /**
   * Проверяет форму и отправляет её либо имитирует успех в тестовом режиме.
   * @param {SubmitEvent} event Событие отправки формы.
   * @returns {Promise<void>}
   */
  async function submitForm(event) {
    event.preventDefault();
    status.textContent = '';

    const sourceData = new FormData(form);
    if (clean(sourceData.get('website'))) return;
    if (!validateForm()) {
      form.querySelector('[aria-invalid="true"]')?.focus();
      return;
    }

    setSendingState(true);
    if (TEST_MODE) {
      window.setTimeout(() => {
        form.reset();
        setSendingState(false);
        showStatus('success', SUCCESS_MESSAGE);
      }, 450);
      return;
    }

    try {
      const response = await fetch(FORM_ENDPOINT, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(buildRequestData(sourceData))
      });
      const result = await response.json();
      if (!response.ok || !result.success) throw new Error('Server rejected request');
      form.reset();
      showStatus('success', SUCCESS_MESSAGE);
    } catch (error) {
      showStatus('error', ERROR_MESSAGE);
    } finally {
      setSendingState(false);
    }
  }

  /** Очищает ошибку редактируемого поля. @param {Event} event Событие ввода. @returns {void} */
  function clearEditedFieldError(event) {
    if (event.target.id) setFieldError(event.target.id, '');
  }

  form.addEventListener('submit', submitForm);
  form.addEventListener('input', clearEditedFieldError);
  form.addEventListener('change', clearEditedFieldError);

  form.querySelector('#sf-captcha')?.addEventListener('change', (event) => {
    const tokenField = form.querySelector('[name="captcha_token"]');
    if (tokenField) tokenField.value = event.target.checked ? 'local-placeholder' : '';
    const error = form.querySelector('#sf-captcha-error');
    if (error) error.textContent = '';
  });
})();
