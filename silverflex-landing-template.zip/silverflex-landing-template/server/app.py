"""
Назначение: локально раздаёт сайт и принимает заявки SilverFlex.
Зависимости: только стандартная библиотека Python и переменные окружения.
От этого файла зависит: отправка формы на SMTP и/или в Telegram.

Запуск: python server/app.py
ВНИМАНИЕ: файл .env автоматически не читается. Переменные из .env.example
нужно задать в окружении сервера или в панели будущего хостинга.
"""

from __future__ import annotations

import json
import os
import re
import smtplib
import ssl
import threading
import time
import urllib.parse
import urllib.request
from collections import defaultdict, deque
from email.message import EmailMessage
from http import HTTPStatus
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any


# ===== РАЗДЕЛ: Конфигурация =====

PROJECT_ROOT = Path(__file__).resolve().parent.parent
MAX_BODY_BYTES = 64 * 1024
RATE_LIMIT_REQUESTS = 5
RATE_LIMIT_WINDOW_SECONDS = 10 * 60
PHONE_PATTERN = re.compile(r"^[+\d\s().-]+$")
EMAIL_PATTERN = re.compile(r"^[^\s@]+@[^\s@]+\.[^\s@]+$")
CAPTCHA_VERIFY_URLS = {
    "hcaptcha": "https://api.hcaptcha.com/siteverify",
    "turnstile": "https://challenges.cloudflare.com/turnstile/v0/siteverify",
    "recaptcha": "https://www.google.com/recaptcha/api/siteverify",
}
REQUEST_LOG: dict[str, deque[float]] = defaultdict(deque)
REQUEST_LOG_LOCK = threading.Lock()


# ===== РАЗДЕЛ: Проверка данных =====

def env_flag(name: str, default: bool = False) -> bool:
    """Читает логическую переменную окружения. Возвращает True или False."""
    value = os.getenv(name, str(default)).strip().lower()
    return value in {"1", "true", "yes", "on"}


def clean(value: Any, limit: int) -> str:
    """Нормализует пользовательское значение и ограничивает его длину."""
    if not isinstance(value, str):
        return ""
    return " ".join(value.strip().split())[:limit]


def is_rate_limited(client_ip: str) -> bool:
    """Ограничивает частые заявки с одного адреса в памяти процесса."""
    now = time.monotonic()
    with REQUEST_LOG_LOCK:
        timestamps = REQUEST_LOG[client_ip]
        while timestamps and now - timestamps[0] > RATE_LIMIT_WINDOW_SECONDS:
            timestamps.popleft()
        if len(timestamps) >= RATE_LIMIT_REQUESTS:
            return True
        timestamps.append(now)
    return False


def verify_captcha(token: str, client_ip: str) -> bool:
    """Проверяет заглушку либо выбранного внешнего провайдера капчи."""
    provider = os.getenv("CAPTCHA_PROVIDER", "placeholder").strip().lower()
    if provider == "placeholder":
        return token == "local-placeholder"

    verify_url = CAPTCHA_VERIFY_URLS.get(provider)
    secret = os.getenv("CAPTCHA_SECRET_KEY", "").strip()
    if not verify_url or not secret or not token:
        return False

    # ТОЧКА РАСШИРЕНИЯ: при смене провайдера добавьте его URL в таблицу выше.
    body = urllib.parse.urlencode(
        {"secret": secret, "response": token, "remoteip": client_ip}
    ).encode("utf-8")
    request = urllib.request.Request(verify_url, data=body, method="POST")
    try:
        with urllib.request.urlopen(request, timeout=8) as response:
            result = json.loads(response.read().decode("utf-8"))
        return bool(result.get("success"))
    except (OSError, ValueError, json.JSONDecodeError):
        return False


def validate_payload(payload: dict[str, Any], client_ip: str) -> tuple[dict[str, Any], dict[str, str]]:
    """Проверяет заявку. Возвращает очищенные данные и ошибки полей."""
    data = {
        "name": clean(payload.get("name"), 80),
        "company": clean(payload.get("company"), 120),
        "phone": clean(payload.get("phone"), 30),
        "email": clean(payload.get("email"), 120),
        "packaging_type": clean(payload.get("packagingType"), 120),
        "quantity": clean(payload.get("quantity"), 80),
        "message": clean(payload.get("message"), 1500),
        "page": clean(payload.get("page"), 500),
        "website": clean(payload.get("website"), 200),
        "captcha_token": clean(payload.get("captchaToken"), 4000),
        "consent": payload.get("consent") is True,
    }
    errors: dict[str, str] = {}
    phone_digits = re.sub(r"\D", "", data["phone"])

    if len(data["name"]) < 2:
        errors["name"] = "Укажите имя."
    phone_provided = len(phone_digits) > 1
    email_provided = bool(data["email"])
    if not phone_provided:
        data["phone"] = ""
    if not phone_provided and not email_provided:
        errors["phone"] = "Укажите телефон или e-mail."
    elif phone_provided and (
        not PHONE_PATTERN.fullmatch(data["phone"])
        or not 9 <= len(phone_digits) <= 15
    ):
        errors["phone"] = "Укажите корректный телефон."
    if email_provided and not EMAIL_PATTERN.fullmatch(data["email"]):
        errors["email"] = "Укажите корректный e-mail."
    if len(data["message"]) < 5:
        errors["message"] = "Опишите задачу или продукт."
    if not data["consent"]:
        errors["consent"] = "Подтвердите согласие на обработку данных."
    if not verify_captcha(data["captcha_token"], client_ip):
        errors["captcha"] = "Подтвердите, что вы не робот."
    return data, errors


# ===== РАЗДЕЛ: Формирование и доставка заявки =====

def build_message(data: dict[str, Any]) -> tuple[str, str]:
    """Формирует тему и понятный текст заявки без пустых необязательных полей."""
    packaging = data["packaging_type"] or "тип не указан"
    subject = f"Новая заявка с сайта SilverFlex: {data['name']}, {packaging}"
    rows = [
        ("Имя", data["name"]),
        ("Компания", data["company"]),
        ("Телефон", data["phone"]),
        ("E-mail", data["email"]),
        ("Тип упаковки", data["packaging_type"]),
        ("Тираж", data["quantity"]),
        ("Сообщение", data["message"]),
        ("Дата и время", time.strftime("%Y-%m-%d %H:%M:%S")),
        ("Страница", data["page"]),
    ]
    body = "\n".join(f"{label}: {value}" for label, value in rows if value)
    return subject[:180], body


def send_email(subject: str, body: str, reply_to: str) -> bool:
    """Отправляет заявку через SMTP, если все обязательные настройки заданы."""
    host = os.getenv("SMTP_HOST", "").strip()
    recipient = os.getenv("FORM_RECIPIENT_EMAIL", "").strip()
    sender = os.getenv("FORM_SENDER_EMAIL", "").strip()
    if not host or not recipient or not sender:
        return False

    port = int(os.getenv("SMTP_PORT", "465"))
    user = os.getenv("SMTP_USER", "").strip()
    password = os.getenv("SMTP_PASSWORD", "")
    use_ssl = env_flag("SMTP_USE_SSL", True)
    message = EmailMessage()
    message["Subject"] = subject
    message["From"] = sender
    message["To"] = recipient
    if reply_to:
        message["Reply-To"] = reply_to
    message.set_content(body)
    context = ssl.create_default_context()

    if use_ssl:
        with smtplib.SMTP_SSL(host, port, timeout=12, context=context) as server:
            if user:
                server.login(user, password)
            server.send_message(message)
    else:
        with smtplib.SMTP(host, port, timeout=12) as server:
            server.starttls(context=context)
            if user:
                server.login(user, password)
            server.send_message(message)
    return True


def send_telegram(subject: str, body: str) -> bool:
    """Отправляет заявку в Telegram, если токен и идентификатор чата заданы."""
    token = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()
    chat_id = os.getenv("TELEGRAM_CHAT_ID", "").strip()
    if not token or not chat_id:
        return False

    url = f"https://api.telegram.org/bot{token}/sendMessage"
    payload = json.dumps({"chat_id": chat_id, "text": f"{subject}\n\n{body}"}).encode("utf-8")
    request = urllib.request.Request(
        url, data=payload, headers={"Content-Type": "application/json"}, method="POST"
    )
    with urllib.request.urlopen(request, timeout=12) as response:
        return 200 <= response.status < 300


def deliver_request(data: dict[str, Any]) -> bool:
    """Доставляет заявку доступными каналами либо имитирует доставку в тестовом режиме."""
    if env_flag("FORM_TEST_MODE", True):
        return True

    subject, body = build_message(data)
    results: list[bool] = []
    try:
        if os.getenv("SMTP_HOST"):
            results.append(send_email(subject, body, data["email"]))
    except (OSError, smtplib.SMTPException, ValueError):
        results.append(False)
    try:
        if os.getenv("TELEGRAM_BOT_TOKEN"):
            results.append(send_telegram(subject, body))
    except (OSError, ValueError):
        results.append(False)
    return any(results)


# ===== РАЗДЕЛ: HTTP-обработчик =====

class SilverFlexHandler(SimpleHTTPRequestHandler):
    """Раздаёт статические файлы и принимает POST /api/contact."""

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, directory=str(PROJECT_ROOT), **kwargs)

    def send_json(self, status: HTTPStatus, payload: dict[str, Any]) -> None:
        """Отправляет JSON-ответ без технических подробностей."""
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def do_POST(self) -> None:
        """Принимает только заявки формы по согласованному адресу."""
        if self.path != "/api/contact":
            self.send_json(HTTPStatus.NOT_FOUND, {"success": False, "message": "Маршрут не найден."})
            return
        if is_rate_limited(self.client_address[0]):
            self.send_json(HTTPStatus.TOO_MANY_REQUESTS, {"success": False, "message": "Слишком много попыток. Попробуйте позже."})
            return

        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            length = 0
        if length <= 0 or length > MAX_BODY_BYTES:
            self.send_json(HTTPStatus.BAD_REQUEST, {"success": False, "message": "Некорректный размер заявки."})
            return

        try:
            payload = json.loads(self.rfile.read(length).decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError):
            self.send_json(HTTPStatus.BAD_REQUEST, {"success": False, "message": "Некорректные данные заявки."})
            return
        if not isinstance(payload, dict):
            self.send_json(HTTPStatus.BAD_REQUEST, {"success": False, "message": "Некорректные данные заявки."})
            return

        # Honeypot: бот получает нейтральный успех, но сообщение не доставляется.
        if clean(payload.get("website"), 200):
            self.send_json(HTTPStatus.OK, {"success": True})
            return

        data, errors = validate_payload(payload, self.client_address[0])
        if errors:
            self.send_json(HTTPStatus.UNPROCESSABLE_ENTITY, {"success": False, "errors": errors})
            return
        if not deliver_request(data):
            self.send_json(HTTPStatus.SERVICE_UNAVAILABLE, {"success": False, "message": "Канал доставки пока не настроен."})
            return
        self.send_json(HTTPStatus.OK, {"success": True})


def main() -> None:
    """Запускает локальный сервер на адресе из переменных окружения."""
    host = os.getenv("SERVER_HOST", "127.0.0.1")
    port = int(os.getenv("SERVER_PORT", "8000"))
    server = ThreadingHTTPServer((host, port), SilverFlexHandler)
    print(f"SilverFlex: http://{host}:{port}")
    server.serve_forever()


if __name__ == "__main__":
    main()
