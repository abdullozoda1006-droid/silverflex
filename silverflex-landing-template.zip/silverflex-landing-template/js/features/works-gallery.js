/*
 * Назначение: безопасно выводит галерею примеров упаковки SilverFlex.
 * Зависимости: ../data/packaging-data.js, элементы [data-works-grid] и [data-works-count].
 * От этого файла зависит: works.html.
 */

const grid = document.querySelector('[data-works-grid]');
const count = document.querySelector('[data-works-count]');
const WORK_PREFIX = 'Индивидуальная упаковка - ';
const packagingEntries = window.SILVERFLEX_PACKAGING_ENTRIES || [];

/**
 * Создаёт одну карточку подтверждённого примера упаковки.
 * @param {[number, string]} entry Идентификатор изображения и название записи.
 * @param {number} index Порядковый номер карточки.
 * @returns {HTMLElement} Готовая карточка галереи.
 */
function createWorkCard([id, sourceTitle], index) {
  const title = sourceTitle.replace(WORK_PREFIX, '').trim();
  const article = document.createElement('article');
  const link = document.createElement('a');
  const image = document.createElement('img');
  const caption = document.createElement('div');
  const name = document.createElement('strong');
  const note = document.createElement('span');
  const arrow = document.createElement('span');

  article.className = 'full-work-card';
  link.href = 'index.html#contact';
  link.setAttribute('aria-label', `Обсудить упаковку ${title}`);
  image.src = `assets/works/${id}.webp`;
  image.alt = `Пример упаковки ${title}`;
  image.loading = 'lazy';
  image.width = 800;
  image.height = 800;
  name.textContent = title;
  note.textContent = String(index + 1).padStart(2, '0');
  arrow.className = 'full-work-arrow';
  arrow.setAttribute('aria-hidden', 'true');
  arrow.textContent = '↗';
  caption.className = 'full-work-caption';
  caption.append(note, name, arrow);
  link.append(image, caption);
  article.append(link);
  return article;
}

if (grid && count) {
  const works = packagingEntries.filter(([, title]) => title.startsWith(WORK_PREFIX));
  const fragment = document.createDocumentFragment();
  works.forEach((entry, index) => fragment.append(createWorkCard(entry, index)));
  if (works.length) {
    grid.replaceChildren(fragment);
    count.textContent = String(works.length);
  }
}
