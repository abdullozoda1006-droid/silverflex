/*
 * Назначение: универсальное окно подробностей для упаковки и материалов.
 * Зависимости: элементы [data-detail], [data-detail-dialog] и поля окна в index.html.
 * От этого файла зависит: раскрытие карточек без перехода на отдельные страницы.
 */

(() => {
  'use strict';

  const dialog = document.querySelector('[data-detail-dialog]');
  if (!dialog) return;

  const details = {
    printed: {
      label: 'Вид упаковки',
      title: 'Плёнка с печатью',
      description: 'Рулонный материал с индивидуальным оформлением для фасовочного оборудования заказчика.',
      uses: ['Автоматическая фасовка', 'Бакалея', 'Выпечка', 'Замороженные продукты'],
      questions: ['Ширина полотна и намотка под линию', 'Макет', 'Тираж']
    },
    clear: {
      label: 'Вид упаковки',
      title: 'Прозрачная плёнка',
      description: 'Вариант для упаковки, в которой продукт должен оставаться видимым покупателю.',
      uses: ['Продукты, которые покупатель должен видеть'],
      questions: ['Материал: ПЭ, ПП или ПЭТ', 'Способ фасовки', 'Условия хранения']
    },
    laminate: {
      label: 'Вид упаковки',
      title: 'Многослойные материалы',
      description: 'Структуры из нескольких слоёв, когда упаковке нужен набор разных свойств.',
      uses: ['Задачи, где одной плёнки недостаточно по свойствам'],
      questions: ['Условия хранения', 'Срок годности', 'Структура слоёв']
    },
    pe: {
      label: 'Материал',
      title: 'Полиэтилен · PE',
      description: 'Гибкий материал, который может применяться отдельно или входить в многослойную структуру.',
      uses: ['Упаковочные пакеты', 'Свариваемый слой', 'Рулонная упаковка'],
      questions: ['Толщина и ширина', 'Температура сварки', 'Нагрузка на упаковку']
    },
    bopp: {
      label: 'Материал',
      title: 'Полипропилен · BOPP',
      description: 'Материал с хорошей прозрачностью и аккуратным внешним видом для рулонной упаковки.',
      uses: ['Бакалея', 'Кондитерские изделия', 'Продукты, которым важен внешний вид'],
      questions: ['Требования к прозрачности', 'Тип печати и макет', 'Формат рулона']
    },
    pet: {
      label: 'Материал',
      title: 'Полиэстер · PET',
      description: 'Стабильный материал, который часто используется как внешний слой многослойной упаковки.',
      uses: ['Ламинированная упаковка', 'Печать с защитой изображения', 'Структуры с повышенной стабильностью'],
      questions: ['Состав всей структуры', 'Требования к печати', 'Условия фасовки']
    },
    barrier: {
      label: 'Материал',
      title: 'Барьерные структуры',
      description: 'Комбинация слоёв подбирается по продукту, хранению, фасовке и нужным защитным свойствам.',
      uses: ['Продукты с особыми условиями хранения', 'Замороженная продукция', 'Многослойная упаковка'],
      questions: ['Продукт и ожидаемый срок хранения', 'Температурный режим', 'Требования к защите продукта']
    }
  };

  const title = dialog.querySelector('[data-dialog-title]');
  const label = dialog.querySelector('[data-dialog-label]');
  const description = dialog.querySelector('[data-dialog-description]');
  const uses = dialog.querySelector('[data-dialog-uses]');
  const questions = dialog.querySelector('[data-dialog-questions]');
  const quoteLink = dialog.querySelector('[data-dialog-quote]');
  const closeButton = dialog.querySelector('[data-dialog-close]');

  /* ===== РАЗДЕЛ: Заполнение окна ===== */

  /**
   * Безопасно создаёт пункты списка из массива строк.
   * @param {HTMLUListElement} list Элемент списка для заполнения.
   * @param {string[]} items Тексты пунктов.
   * @returns {void}
   */
  function renderList(list, items) {
    list.replaceChildren();
    items.forEach((item) => {
      const listItem = document.createElement('li');
      listItem.textContent = item;
      list.append(listItem);
    });
  }

  /**
   * Открывает окно с данными выбранной карточки.
   * @param {string} detailKey Ключ записи в объекте details.
   * @returns {void}
   */
  function openDialog(detailKey) {
    const item = details[detailKey];
    if (!item) return;

    label.textContent = item.label;
    title.textContent = item.title;
    description.textContent = item.description;
    quoteLink.dataset.quoteSubject = item.title;
    renderList(uses, item.uses);
    renderList(questions, item.questions);
    dialog.showModal();
  }

  /**
   * Закрывает окно по отдельной кнопке.
   * @returns {void}
   */
  function closeDialog() {
    dialog.close();
  }

  /**
   * Закрывает окно, если посетитель нажал на затемнённую область.
   * @param {MouseEvent} event Событие нажатия по окну.
   * @returns {void}
   */
  function closeFromBackdrop(event) {
    if (event.target === dialog) closeDialog();
  }

  document.querySelectorAll('[data-detail]').forEach((trigger) => {
    trigger.addEventListener('click', () => openDialog(trigger.dataset.detail));
  });
  closeButton.addEventListener('click', closeDialog);
  dialog.addEventListener('click', closeFromBackdrop);
  quoteLink.addEventListener('click', closeDialog);
})();
