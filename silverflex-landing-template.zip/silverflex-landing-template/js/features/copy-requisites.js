/*
 * Назначение: копирует реквизиты SilverFlex из видимого списка.
 * Зависимости: [data-requisites], [data-copy-requisites], Clipboard API.
 * От этого файла зависит: contacts.html.
 */

(() => {
  'use strict';

  const list = document.querySelector('[data-requisites]');
  const button = document.querySelector('[data-copy-requisites]');
  const status = document.querySelector('[data-copy-status]');
  if (!list || !button || !status) return;

  /** Собирает реквизиты из строк списка. @returns {string} Текст для буфера обмена. */
  function getRequisitesText() {
    return Array.from(list.querySelectorAll('.requisite-row')).map((row) => {
      const label = row.querySelector('dt')?.textContent.trim() || '';
      const value = row.querySelector('dd')?.textContent.trim() || '';
      return `${label}: ${value}`;
    }).join('\n');
  }

  /** Копирует текст через современный API или безопасный запасной способ. @returns {Promise<void>} */
  async function copyRequisites() {
    const text = getRequisitesText();
    try {
      await navigator.clipboard.writeText(text);
      status.textContent = 'Реквизиты скопированы.';
    } catch (error) {
      status.textContent = 'Не удалось скопировать автоматически. Выделите реквизиты вручную.';
    }
  }

  button.addEventListener('click', copyRequisites);
})();
