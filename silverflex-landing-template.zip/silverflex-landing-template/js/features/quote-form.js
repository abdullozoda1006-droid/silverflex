/*
 * Назначение: выбор темы заявки и клиентская проверка демонстрационной формы.
 * Зависимости: форма [data-quote-form] и ссылки [data-quote-subject] в index.html.
 * От этого файла зависит: понятная обратная связь в шаблоне формы.
 * ВНИМАНИЕ: перед публикацией подключить серверный обработчик и повторить проверки на сервере.
 */

(() => {
  'use strict';

  const form = document.querySelector('[data-quote-form]');
  if (!form) return;

  const status = form.querySelector('[data-form-status]');
  const productField = form.elements.product;
  const fieldRules = {
    name: { empty: 'Укажите имя.', max: 80 },
    contact: { empty: 'Укажите телефон или email.', max: 120 },
    product: { empty: 'Расскажите, что нужно упаковать.', max: 160 }
  };

  /* ===== РАЗДЕЛ: Подстановка выбранной темы ===== */

  /**
   * Подставляет выбранное направление в поле продукта.
   * @param {MouseEvent} event Событие нажатия по ссылке.
   * @returns {void}
   */
  function applyQuoteSubject(event) {
    const trigger = event.currentTarget;
    const subject = trigger.dataset.quoteSubject;
    if (!subject) return;
    productField.value = subject;
  }

  /* ===== РАЗДЕЛ: Проверка полей ===== */

  /**
   * Показывает ошибку рядом с указанным полем.
   * @param {string} fieldName Имя поля формы.
   * @param {string} message Текст ошибки или пустая строка.
   * @returns {void}
   */
  function showFieldError(fieldName, message) {
    const field = form.elements[fieldName];
    const error = form.querySelector(`[data-error-for="${fieldName}"]`);
    if (!field || !error) return;
    field.setAttribute('aria-invalid', String(Boolean(message)));
    error.textContent = message;
  }

  /**
   * Проверяет текстовые поля формы на пустое значение и допустимую длину.
   * @returns {boolean} true, если текстовые поля заполнены корректно.
   */
  function validateTextFields() {
    let isValid = true;

    Object.entries(fieldRules).forEach(([fieldName, rule]) => {
      const value = form.elements[fieldName].value.trim();
      let message = '';
      if (!value) message = rule.empty;
      else if (value.length > rule.max) message = `Не больше ${rule.max} символов.`;
      showFieldError(fieldName, message);
      if (message) isValid = false;
    });

    return isValid;
  }

  /**
   * Проверяет согласие на обработку данных.
   * @returns {boolean} true, если согласие отмечено.
   */
  function validateConsent() {
    const isChecked = form.elements.consent.checked;
    showFieldError('consent', isChecked ? '' : 'Подтвердите согласие, чтобы продолжить.');
    return isChecked;
  }

  /**
   * Проверяет демонстрационную форму и показывает результат без отправки данных.
   * @param {SubmitEvent} event Событие отправки формы.
   * @returns {void}
   */
  function handleSubmit(event) {
    event.preventDefault();
    status.textContent = '';

    const isValid = validateTextFields() && validateConsent();
    if (!isValid) {
      const firstInvalidField = form.querySelector('[aria-invalid="true"]');
      firstInvalidField?.focus();
      return;
    }

    status.textContent = 'Форма заполнена корректно. Для реальной отправки нужно подключить серверный обработчик.';
  }

  document.querySelectorAll('[data-quote-subject]').forEach((trigger) => {
    trigger.addEventListener('click', applyQuoteSubject);
  });
  form.addEventListener('submit', handleSubmit);
})();
