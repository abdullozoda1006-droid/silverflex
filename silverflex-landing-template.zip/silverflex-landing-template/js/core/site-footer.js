/*
 * Назначение: единый подвал со ссылками, контактами и социальными каналами.
 * Зависимости: css/styles.css и assets/cinova.webp.
 * От этого файла зависят: все страницы сайта с элементом <site-footer>.
 */

(() => {
  'use strict';

  class SiteFooter extends HTMLElement {
    /** Создаёт одинаковый подвал на каждой странице. @returns {void} */
    connectedCallback() {
      this.innerHTML = `
        <footer class="site-footer">
          <div class="container footer-grid">
            <div class="footer-brand">
              <img class="footer-logo" src="assets/logo.png" alt="SilverFlex" width="357" height="71">
              <img class="footer-photo" src="assets/cinova.webp" alt="Производство SilverFlex" width="1000" height="750" loading="lazy">
              <p>Гибкая упаковка и рулонные материалы для пищевых производств.</p>
            </div>

            <nav class="footer-nav" aria-label="Навигация в подвале">
              <strong>Разделы</strong>
              <a href="index.html#production">Производство</a>
              <a href="index.html#packaging">Продукция</a>
              <a href="works.html">Готовые работы</a>
              <a href="about.html">О компании</a>
              <a href="contacts.html">Контакты</a>
            </nav>

            <div class="footer-contacts">
              <strong>Контакты</strong>
              <a href="tel:+375257104802">+375 (25) 710-48-02</a>
              <a href="tel:+375445053137">+375 (44) 505-31-37</a>
              <a href="mailto:silverflex.f@mail.ru">silverflex.f@mail.ru</a>
              <address>220140, Республика Беларусь,<br>Минск, ул. Домбровская, 10</address>
            </div>

            <div class="footer-cta">
              <strong>Обсудить упаковку</strong>
              <p>Опишите продукт и примерный объём — уточним параметры заказа.</p>
              <a class="button button-light button-small" href="index.html#contact">Запросить расчёт</a>
              <div class="footer-socials" aria-label="Социальные сети и мессенджеры">
                <a href="https://wa.me/375257104802" target="_blank" rel="noopener noreferrer" aria-label="Написать в WhatsApp">WA</a>
              </div>
            </div>
          </div>
          <div class="container footer-bottom">
            <span>© SilverFlex</span>
            <span>ООО «СильверФлекс» · УНП 190726112</span>
          </div>
        </footer>`;
    }
  }

  if (!customElements.get('site-footer')) {
    customElements.define('site-footer', SiteFooter);
  }
})();
