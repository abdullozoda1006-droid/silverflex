/*
 * Назначение: управление мобильным меню лендинга.
 * Зависимости: элементы [data-menu-toggle] и [data-mobile-menu] в index.html и about.html.
 * От этого файла зависит: открытие, закрытие и доступность мобильной навигации.
 */

(() => {
  'use strict';

  const menuToggle = document.querySelector('[data-menu-toggle]');
  const mobileMenu = document.querySelector('[data-mobile-menu]');

  if (!menuToggle || !mobileMenu) return;

  /* ===== РАЗДЕЛ: Состояние меню ===== */

  /**
   * Устанавливает открытое или закрытое состояние мобильного меню.
   * @param {boolean} isOpen Нужно ли открыть меню.
   * @returns {void}
   */
  function setMenuState(isOpen) {
    menuToggle.setAttribute('aria-expanded', String(isOpen));
    menuToggle.setAttribute('aria-label', isOpen ? 'Закрыть меню' : 'Открыть меню');
    mobileMenu.hidden = !isOpen;
    document.body.classList.toggle('menu-open', isOpen);
  }

  /**
   * Переключает текущее состояние мобильного меню.
   * @returns {void}
   */
  function toggleMenu() {
    const isOpen = menuToggle.getAttribute('aria-expanded') === 'true';
    setMenuState(!isOpen);
  }

  /**
   * Закрывает меню после выбора якорной ссылки.
   * @param {MouseEvent} event Событие нажатия внутри меню.
   * @returns {void}
   */
  function closeAfterNavigation(event) {
    if (event.target.closest('a')) setMenuState(false);
  }

  /**
   * Закрывает меню при переходе на широкую компоновку.
   * @param {MediaQueryListEvent} event Изменение медиазапроса.
   * @returns {void}
   */
  function closeOnDesktop(event) {
    if (event.matches) setMenuState(false);
  }

  /**
   * Выравнивает целевую секцию с учётом высоты хедера и безопасного отступа.
   * @param {ScrollBehavior} behavior Режим прокрутки при переходе.
   * @returns {void}
   */
  function alignHashTarget(behavior = 'auto') {
    const targetId = decodeURIComponent(window.location.hash.slice(1));
    if (!targetId) return;
    const target = document.getElementById(targetId);
    if (!target) return;
    const root = document.documentElement;
    const previousBehavior = root.style.scrollBehavior;
    const headerHeight = document.querySelector('[data-header]')?.getBoundingClientRect().height || 0;
    const anchorGap = Number.parseFloat(getComputedStyle(root).getPropertyValue('--anchor-gap')) || 0;
    const contentOffset = Number.parseFloat(getComputedStyle(target).paddingTop) || 0;
    const targetTop = target.getBoundingClientRect().top + window.scrollY + contentOffset - headerHeight - anchorGap;
    root.style.scrollBehavior = 'auto';
    window.scrollTo({ top: Math.max(0, targetTop), behavior });
    window.requestAnimationFrame(() => { root.style.scrollBehavior = previousBehavior; });
  }

  /** Подсвечивает пункт текущего раздела главной страницы. @returns {void} */
  function updateActiveNavigation() {
    const pageName = window.location.pathname.split('/').pop() || 'index.html';
    if (pageName !== 'index.html' && pageName !== '') return;
    const target = window.location.hash || '#top';
    const menuTarget = target === '#packaging' || target === '#materials'
      ? '#packaging'
      : target === '#production' ? '#production' : '#top';
    document.querySelectorAll('.desktop-nav a, .mobile-menu a:not(.button)').forEach((link) => {
      link.removeAttribute('aria-current');
      if (link.getAttribute('href') === `index.html${menuTarget}`) {
        link.setAttribute('aria-current', 'page');
      }
    });
  }

  menuToggle.addEventListener('click', toggleMenu);
  mobileMenu.addEventListener('click', closeAfterNavigation);
  window.matchMedia('(min-width: 1181px)').addEventListener('change', closeOnDesktop);
  window.addEventListener('load', () => {
    alignHashTarget('auto');
    updateActiveNavigation();
  });
  window.addEventListener('hashchange', () => {
    alignHashTarget('smooth');
    updateActiveNavigation();
  });
})();
