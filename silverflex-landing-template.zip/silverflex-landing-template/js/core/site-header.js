/*
 * Назначение: единый хедер и навигация для всех страниц SilverFlex.
 * Зависимости: css/styles.css и js/core/navigation.js.
 * От этого файла зависят: index.html, about.html, works.html, contacts.html.
 */

(() => {
  'use strict';

  const NAV_ITEMS = [
    ['home', 'index.html#top', 'Главная'],
    ['products', 'index.html#packaging', 'Продукция'],
    ['production', 'index.html#production', 'Производство'],
    ['works', 'works.html', 'Готовые работы'],
    ['about', 'about.html', 'О компании'],
    ['contacts', 'contacts.html', 'Контакты']
  ];

  /**
   * Возвращает одинаковые ссылки навигации для десктопа и телефона.
   * @param {string} activeKey Ключ активной страницы.
   * @returns {string} HTML-разметка ссылок.
   */
  function renderLinks(activeKey) {
    return NAV_ITEMS.map(([key, href, label]) => {
      const current = key === activeKey ? ' aria-current="page"' : '';
      return `<a href="${href}"${current}>${label}</a>`;
    }).join('');
  }

  class SiteHeader extends HTMLElement {
    connectedCallback() {
      const activeKey = this.getAttribute('active') || '';
      const links = renderLinks(activeKey);
      this.innerHTML = `
        <header class="site-header" data-header>
          <div class="container header-inner">
            <a class="brand" href="index.html#top" aria-label="SilverFlex — на главную страницу">
              <img src="assets/logo.png" alt="SilverFlex" width="357" height="71">
            </a>
            <nav class="desktop-nav" aria-label="Основная навигация">${links}</nav>
            <a class="button button-small header-action" href="index.html#contact">Запросить расчёт</a>
            <button class="menu-toggle" type="button" aria-expanded="false" aria-controls="mobile-menu" aria-label="Открыть меню" data-menu-toggle><span></span><span></span><span></span></button>
          </div>
          <nav class="mobile-menu" id="mobile-menu" aria-label="Мобильная навигация" data-mobile-menu hidden>
            <div class="container mobile-menu-inner">${links}<a class="button" href="index.html#contact">Запросить расчёт</a></div>
          </nav>
        </header>`;
    }
  }

  customElements.define('site-header', SiteHeader);
})();
